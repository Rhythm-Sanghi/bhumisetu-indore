Indore reviewed reference data
NOT A CERTIFIED LAND RECORD

© OpenStreetMap contributors where indicated. ODbL 1.0: https://opendatacommons.org/licenses/odbl/1-0/
Retain per-source attribution and applicable licence obligations when distributing.
GeoJSON/CSV coordinates: longitude, latitude WGS84. GeoPackage: EPSG:32643 metres.
Review acceptance acknowledges a finding or relationship; it does not certify geometry.
Validation report includes unresolved findings and complete decision history.
